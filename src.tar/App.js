import {Component} from 'react'

import ProfileItem from './components/ProfileItem'

import './App.css'

const stringifiedInitialUsersList = localStorage.getItem('initialUsersList')
let initialUsersList = JSON.parse(stringifiedInitialUsersList)

if (initialUsersList === null) {
  initialUsersList = [
    {
      id: 2,
      firstName: 'Jaswanth',
      middleName: '',
      lastName: '',
      imgUrl:
        'https://res.cloudinary.com/jayakrishnavamsi/image/upload/v1667128940/jaswanth_dgovyw.jpg',
      profileId: 'JSS2',
      email: 'madajaswanth@gmail.com',
      password: 'jaswanth@12345',
      gender: 'Male',
      dob: '2001-11-21',
      age: '20',
      caste: 'OC',
      permanentAddress: 'Chilakaluripet',
      currentAddress: 'Chilakaluripet',
      occupation: 'Developer',
      company: 'Meta',
      salary: '300000',
      experience: '1',
      castePreference: 'OC',
      agePreference: '20',
      partnerSalary: '200000',
      phoneNumber: '9565236548',
    },
    {
      id: 1,
      firstName: 'Sai Kiran',
      middleName: '',
      lastName: '',
      imgUrl:
        'https://res.cloudinary.com/jayakrishnavamsi/image/upload/v1667129305/Sai_Kiran_bivsxb.jpg',
      profileId: 'SKK1',
      email: 'saikiran@gmail.com',
      password: 'saikiran@12345',
      gender: 'Male',
      dob: '2002-3-2',
      age: '20',
      caste: 'OC',
      permanentAddress: 'Chilakaluripet',
      currentAddress: 'Chilakaluripet',
      occupation: 'Music Director',
      company: 'Aditya',
      salary: '1000000',
      experience: '1',
      castePreference: 'OC',
      agePreference: '18',
      partnerSalary: '500000',
      phoneNumber: '9182456548',
    },
    {
      id: 0,
      firstName: 'Karthikeya',
      middleName: '',
      lastName: '',
      imgUrl:
        'https://res.cloudinary.com/jayakrishnavamsi/image/upload/c_crop,h_771,q_100,w_927/v1667129655/Karthikeya_jvvmkg.jpg',
      profileId: 'KKK0',
      email: 'saikiran@gmail.com',
      password: 'saikiran@12345',
      gender: 'Male',
      dob: '2002-3-25',
      age: '20',
      caste: 'OC',
      permanentAddress: 'Chilakaluripet',
      currentAddress: 'Chilakaluripet',
      occupation: 'Music Director',
      company: 'Aditya',
      salary: '1000000',
      experience: '1',
      castePreference: 'OC',
      agePreference: '18',
      partnerSalary: '500000',
      phoneNumber: '9182456548',
    },
  ]
}

class App extends Component {
  state = {
    usersList: initialUsersList,
    filteredUserList: [],
    isLandingVisible: true,
    isSignUpvisible: false,
    isDetailedViewVisible: false,
    dropdownvisible: false,
    dvCardElement: '',
    isLoggedIn: false,
    firstName: '',
    middleName: '',
    lastName: '',
    email: '',
    password: '',
    gender: 'Male',
    dob: '',
    caste: '',
    permanentAddress: '',
    currentAddress: '',
    occupation: '',
    company: '',
    salary: '',
    experience: '',
    castePreference: '',
    agePreference: '',
    partnerSalary: '',
    phoneNumber: '',
    filterOption: 'age',
    filterInput: '',
  }

  onLandingSignupClick = () => {
    this.setState({
      isLandingVisible: false,
      isSignUpvisible: true,
      isLoggedIn: false,
      dropdownvisible: false,
      email: '',
      password: '',
    })
  }

  onLandingLoginClick = () => {
    this.setState({
      isLandingVisible: false,
      isSignUpvisible: false,
      isLoggedIn: false,
      dropdownvisible: false,
      filteredUserList: [],
      email: '',
      password: '',
    })
  }

  onLogoutClick = () => {
    this.setState({
      isLandingVisible: true,
      isSignUpvisible: false,
      dropdownvisible: false,
      isDetailedViewVisible: false,
      isLoggedIn: false,
    })
  }

  onfirstNameChange = event => {
    this.setState({firstName: event.target.value})
  }

  onmiddleNameChange = event => {
    this.setState({middleName: event.target.value})
  }

  onlastNameChange = event => {
    this.setState({lastName: event.target.value})
  }

  onemailChange = event => {
    this.setState({email: event.target.value})
  }

  onpasswordChange = event => {
    this.setState({password: event.target.value})
  }

  ongenderChange = event => {
    this.setState({gender: event.target.value})
  }

  ondobChange = event => {
    this.setState({dob: event.target.value})
  }

  oncasteChange = event => {
    this.setState({caste: event.target.value})
  }

  oncompanyChange = event => {
    this.setState({company: event.target.value})
  }

  onpermanentaddChange = event => {
    this.setState({permanentAddress: event.target.value})
  }

  oncurrentaddrChange = event => {
    this.setState({currentAddress: event.target.value})
  }

  onoccupationChange = event => {
    this.setState({occupation: event.target.value})
  }

  onsalaryChange = event => {
    this.setState({salary: event.target.value})
  }

  onexpereienceChange = event => {
    this.setState({experience: event.target.value})
  }

  oncastePrefChange = event => {
    this.setState({castePreference: event.target.value})
  }

  onagePrefChange = event => {
    this.setState({agePreference: event.target.value})
  }

  onpartnersalarychange = event => {
    this.setState({partnerSalary: event.target.value})
  }

  onphonenumberChange = event => {
    this.setState({phoneNumber: event.target.value})
  }

  onSignupSubmit = event => {
    event.preventDefault()
    const {
      usersList,
      isLandingVisible,
      isSignUpvisible,
      firstName,
      middleName,
      lastName,
      email,
      password,
      gender,
      dob,
      caste,
      permanentAddress,
      currentAddress,
      occupation,
      company,
      salary,
      experience,
      castePreference,
      agePreference,
      partnerSalary,
      phoneNumber,
    } = this.state

    if (
      firstName === '' ||
      middleName === '' ||
      lastName === '' ||
      email === '' ||
      password === '' ||
      gender === '' ||
      dob === '' ||
      caste === '' ||
      permanentAddress === '' ||
      currentAddress === '' ||
      occupation === '' ||
      company === '' ||
      salary === '' ||
      experience === '' ||
      castePreference === '' ||
      agePreference === '' ||
      partnerSalary === '' ||
      phoneNumber === ''
    ) {
      alert('Enter all fields.')
      return
    }

    function getAge(dateString) {
      const today = new Date()
      const dobArray = dateString.split('-')
      const birthYear = dobArray[0]
      const birthMonth = dobArray[1]
      const birthDay = dobArray[2]
      const birthDate = new Date(birthYear, birthMonth, birthDay)
      let age = today.getFullYear() - birthDate.getFullYear()
      const m = today.getMonth() - birthDate.getMonth()
      if (m < 0 || (m === 0 && today.getDate() < birthDate.getDate())) {
        age = age - 1
      }
      return age
    }

    const age = `${getAge(dob)}`

    const userObjectsList = usersList.filter(
      eachUser => eachUser.email === email,
    )

    if (userObjectsList.length > 0) {
      alert('User Already Exists')
      return
    }

    const profileId = `${firstName[0]}${middleName[0]}${lastName[0]}${usersList.length}`

    const newUser = {
      id: usersList.length,
      profileId,
      firstName,
      middleName,
      lastName,
      imgUrl:
        'https://res.cloudinary.com/jayakrishnavamsi/image/upload/v1667112441/avatar_ajdrat.jpg',
      email,
      password,
      gender,
      dob,
      age,
      caste,
      permanentAddress,
      currentAddress,
      occupation,
      company,
      salary,
      experience,
      castePreference,
      agePreference,
      partnerSalary,
      phoneNumber,
    }

    const newUserList = [newUser, ...usersList]
    const stringifiedNewUserList = JSON.stringify(newUserList)

    localStorage.setItem('initialUsersList', stringifiedNewUserList)

    this.setState(prevState => ({
      usersList: [newUser, ...prevState.usersList],
      firstName: '',
      middleName: '',
      lastName: '',
      email: '',
      password: '',
      gender: '',
      dob: '',
      caste: '',
      permanentAddress: '',
      currentAddress: '',
      occupation: '',
      company: '',
      salary: '',
      experience: '',
      castePreference: '',
      agePreference: '',
      partnerSalary: '',
      phoneNumber: '',
    }))
    alert('Account Created Successfully ☑. Please Login...')
  }

  onLoginSubmit = event => {
    event.preventDefault()
    const {usersList, email, password} = this.state

    const userObjectList = usersList.filter(
      eachUser => eachUser.email === email,
    )

    if (userObjectList.length === 0) {
      alert('Invalid User')
      return
    }

    if (userObjectList[0].password !== password) {
      alert('Invalid Password')
      return
    }

    this.setState({isLoggedIn: true, dropdownvisible: false})
  }

  onChangeFilterOption = event => {
    console.log(event.target.value)
    this.setState({
      filteredUserList: [],
      filterOption: event.target.value,
      filterInput: '',
    })
  }

  onChangeFilterInput = event => {
    const filterInput = event.target.value
    const {usersList, filterOption} = this.state
    this.setState({filterInput: event.target.value})

    if (filterInput === '') {
      //   console.log(filterInput)
      this.setState({filteredUserList: []})
    } else {
      const filteredList = usersList.filter(eachUser =>
        eachUser[filterOption]
          .toLowerCase()
          .includes(filterInput.toLowerCase()),
      )
      //   console.log(usersList[0][filterOption])
      //   console.log(filterInput)
      //   console.log(filteredList)
      if (filteredList.length === 0) {
        this.setState({filteredUserList: ''})
      } else {
        this.setState({filteredUserList: filteredList})
      }
    }
  }

  cardClick = id => {
    const {usersList} = this.state
    const fuserProfileslist = usersList.filter(eachUser => eachUser.id === id)

    this.setState({
      isDetailedViewVisible: true,
      dvCardElement: fuserProfileslist[0],
    })
  }

  backClicked = () => {
    this.setState({dvCardElement: '', isDetailedViewVisible: false})
  }

  toggledropdownvisibility = () => {
    const {dropdownvisible} = this.state
    if (dropdownvisible) {
      this.setState({dropdownvisible: false})
    } else {
      this.setState({dropdownvisible: true})
    }
  }

  homeClick = () => {
    this.setState({
      filteredUserList: [],
      isLandingVisible: true,
      isSignUpvisible: false,
      isDetailedViewVisible: false,
      dropdownvisible: false,
      dvCardElement: '',
      isLoggedIn: false,
    })
  }

  render() {
    const {
      usersList,
      isLandingVisible,
      isSignUpvisible,
      isDetailedViewVisible,
      dropdownvisible,
      dvCardElement,
      isLoggedIn,
      filterOption,
      filterInput,
      firstName,
      middleName,
      lastName,
      email,
      password,
      gender,
      dob,
      caste,
      permanentAddress,
      currentAddress,
      occupation,
      company,
      salary,
      experience,
      castePreference,
      agePreference,
      partnerSalary,
      phoneNumber,
    } = this.state

    let {filteredUserList} = this.state
    let isEmptyList = false

    if (filteredUserList === '') {
      filteredUserList = []
      isEmptyList = true
    } else if (filteredUserList.length === 0) {
      filteredUserList = usersList
    }

    let buttonElement = (
      <>
        {' '}
        <button
          onClick={this.onLandingSignupClick}
          className="auth-button"
          type="button"
        >
          {' '}
          Sign Up{' '}
        </button>
        <button
          onClick={this.onLandingLoginClick}
          className="auth-button"
          type="button"
        >
          {' '}
          Login{' '}
        </button>
      </>
    )
    if (!isLandingVisible && isSignUpvisible && !isLoggedIn) {
      buttonElement = (
        <>
          {' '}
          <button
            onClick={this.onLandingLoginClick}
            className="auth-button"
            type="button"
          >
            {' '}
            Login{' '}
          </button>
        </>
      )
    } else if (!isLandingVisible && !isSignUpvisible && !isLoggedIn) {
      buttonElement = (
        <>
          {' '}
          <button
            onClick={this.onLandingSignupClick}
            className="auth-button"
            type="button"
          >
            {' '}
            Sign Up{' '}
          </button>
        </>
      )
    }
    if (isLoggedIn) {
      buttonElement = (
        <>
          {' '}
          <button
            onClick={this.onLogoutClick}
            className="auth-button"
            type="button"
          >
            {' '}
            Logout{' '}
          </button>
        </>
      )
    }

    return (
      <div>
        <nav id="top-section" className="navbar">
          <div className="inside-nav-bar">
            <div className="img-container">
              <img
                className="logo"
                src="https://res.cloudinary.com/jayakrishnavamsi/image/upload/v1667031981/logo_xrfjwg.png"
                alt="logo"
              />
              <h1 className="company-title"> Weddy💘</h1>
            </div>
            <div className="from-medium-features-container">
              <a
                onClick={this.homeClick}
                href="#top-section"
                className="feature-name"
              >
                {' '}
                Home{' '}
              </a>
              <a href="#who-are-we-section" className="feature-name">
                {' '}
                Who are we{' '}
              </a>
              <a href="#why-us-section" className="feature-name">
                {' '}
                Why us{' '}
              </a>
              <a href="#subscription-section" className="feature-name">
                {' '}
                Subscriptions{' '}
              </a>
              <a href="#map-section" className="feature-name">
                {' '}
                Locate us{' '}
              </a>
              <a href="#footer-section" className="feature-name">
                {' '}
                Contact us{' '}
              </a>
              {buttonElement}
            </div>
            <button
              onClick={this.toggledropdownvisibility}
              type="button"
              className="dash-btn"
            >
              ☰
            </button>
          </div>
        </nav>
        {dropdownvisible && (
          <div className="hide" id="featuresContainer">
            <hr className="first-hr" />
            <a
              onClick={this.homeClick}
              href="#top-section"
              className="feature-name"
            >
              {' '}
              Home{' '}
            </a>
            <hr />
            <a href="#who-are-we-section" className="feature-name">
              {' '}
              Who are we{' '}
            </a>
            <hr />
            <a href="#why-us-section" className="feature-name">
              {' '}
              Why us{' '}
            </a>
            <hr className="last-hr" />
            <a href="#subscription-section" className="feature-name">
              {' '}
              Subscriptions{' '}
            </a>
            <hr className="last-hr" />
            <a href="#map-section" className="feature-name">
              {' '}
              Locate us{' '}
            </a>
            <hr className="last-hr" />
            <a href="#footer-section" className="feature-name">
              {' '}
              Contact us{' '}
            </a>
            <hr className="last-hr" />
            <div className="btns-container">{buttonElement}</div>
          </div>
        )}
        {isLoggedIn && (
          <>
            {!isDetailedViewVisible && (
              <div className="user-home-page">
                <h1 className="home-page-title"> ❦ My Dashboard ❦ </h1>
                <div className="home-page-card">
                  <div className="filters-section">
                    <select
                      value={filterOption}
                      onChange={this.onChangeFilterOption}
                      className="filter-select"
                    >
                      <option value="age" selected>
                        {' '}
                        Age{' '}
                      </option>
                      <option value="caste"> Caste </option>
                      <option value="currentAddress"> City </option>
                      <option value="occupation"> Occupation </option>
                      <option value="salary"> Salary </option>
                    </select>
                    <input
                      value={filterInput}
                      onChange={this.onChangeFilterInput}
                      placeholder="Enter Value"
                      className="filter-text"
                      type="text"
                    />
                  </div>
                  <hr />
                  <h1 className="featured-heading"> Featured : </h1>
                  <div className="profiles-section">
                    {filteredUserList.map(eachUser => (
                      <ProfileItem
                        cardClick={this.cardClick}
                        userDetails={eachUser}
                      />
                    ))}
                    {isEmptyList && (
                      <p className="no-results-text"> No Results Found </p>
                    )}
                  </div>
                </div>
              </div>
            )}
            {isDetailedViewVisible && (
              <div className="user-home-page">
                <h1 className="detailed-view-heading">
                  {' '}
                  <span className="icon-symbol">Detailed Info</span> 💞
                </h1>
                <div className="detailedView-card">
                  <div className="detailed-img-container">
                    <img
                      className="detailed-person-img"
                      src={dvCardElement.imgUrl}
                      alt="person-profile"
                    />
                  </div>
                  <div className="detailed-profile-card-txt-cont">
                    <p className="detailed-profiletxt">
                      {' '}
                      Profile-Id: {dvCardElement.profileId}{' '}
                    </p>
                    <p className="detailed-profiletxt">
                      {' '}
                      Name:{' '}
                      <span className="detailed-masked-name">
                        {dvCardElement.firstName}
                      </span>{' '}
                    </p>
                    <p className="detailed-profiletxt">
                      {' '}
                      Age:{' '}
                      <span className="age-number">
                        {' '}
                        {dvCardElement.age}{' '}
                      </span>{' '}
                    </p>
                    <p className="detailed-profiletxt">
                      {' '}
                      Salary:{' '}
                      <span className="age-number">
                        {' '}
                        {dvCardElement.salary}{' '}
                      </span>{' '}
                    </p>
                    <p className="detailed-profiletxt">
                      {' '}
                      Caste/Community:{' '}
                      <span className="age-number">
                        {' '}
                        {dvCardElement.caste}{' '}
                      </span>{' '}
                    </p>
                    <p className="detailed-profiletxt">
                      {' '}
                      Occupation:{' '}
                      <span className="age-number">
                        {' '}
                        {dvCardElement.occupation}{' '}
                      </span>{' '}
                    </p>
                    <p className="detailed-profiletxt">
                      {' '}
                      Partner Salary Preference:{' '}
                      <span className="age-number">
                        {' '}
                        {dvCardElement.partnerSalary}{' '}
                      </span>{' '}
                    </p>
                  </div>
                </div>

                <button
                  onClick={this.backClicked}
                  className="back-btn"
                  type="button"
                >
                  {' '}
                  Back ↺{' '}
                </button>
              </div>
            )}
          </>
        )}

        {!isLoggedIn && (
          <>
            {isLandingVisible && (
              <>
                <div id="" className="bg-container">
                  <h1 className="main-heading">
                    Simply the best place to find a Life Partner
                  </h1>
                </div>
                <div id="who-are-we-section" className="who-are-we-section">
                  <h1 className="section-heading who-are-we-section-title">
                    {' '}
                    Who are we ?{' '}
                  </h1>
                  <div className="who-are-we-section-description">
                    <p className="sample-txt">(Sample Text) </p>
                    <p>
                      The company provides both matchmaking and marriage related
                      services through websites, mobile sites and mobile apps
                      and is also complemented by 110+ company-owned retail
                      outlets. Its flagship matchmaking services are
                      BharatMatrimony, EliteMatrimony and CommunityMatrimony.
                      Besides this, Jodii, a matchmaking service for
                      non-graduates, is available in 10 Indian languages. With a
                      strong leadership in online matrimony, the company has
                      been expanding into the highly unorganised $55 billion
                      marriage services Industry. The goal is to build a billion
                      dollar revenue company and a long lasting institution with
                      a legacy for generations to come.
                    </p>
                    <p className="quote">
                      🌹 M𝚊𝚛𝚛𝚒𝚊𝚐𝚎𝚜 𝚊𝚛𝚎 𝚏𝚒𝚡𝚎𝚍 at{' '}
                      <span className="strikedtxt">𝙷𝚎𝚊𝚟𝚎𝚗</span> 
                      <span className="weddy-text"> Wҽԃԃყ</span> 🌹
                    </p>
                  </div>
                </div>
                <div id="why-us-section" className="why-us-section">
                  <h1 className="section-heading who-are-we-section-title">
                    {' '}
                    Why Us ?{' '}
                  </h1>
                  <div className="why-us-container">
                    <div className="txt-container order">
                      <p className="txt-cont-heading">ENGAGING INTERFACE </p>
                      <p>
                        {' '}
                        With a perfect blend of looks, interactivity, and
                        usability, our matrimonial web design offers an engaging
                        platform for the prospective brides and grooms to carry
                        out their partner search online.{' '}
                      </p>
                    </div>
                    <img
                      className="why-us-img"
                      src="https://res.cloudinary.com/jayakrishnavamsi/image/upload/v1667194797/1_a0r5hy.png"
                      alt="why-us-img"
                    />
                  </div>
                  <div className="why-us-container">
                    <img
                      className="why-us-img"
                      src="https://res.cloudinary.com/jayakrishnavamsi/image/upload/v1667194797/2_jzphmv.png"
                      alt="why-us-img"
                    />
                    <div className="txt-container">
                      <p className="txt-cont-heading">
                        ADVANCED SEARCH OPTIONS{' '}
                      </p>
                      <p>
                        {' '}
                        Apart from the traditional and basic search options, our
                        matrimonial web design also offers advanced search
                        options based on caste, location, astrology, etc.{' '}
                      </p>
                    </div>
                  </div>
                  <div className="why-us-container">
                    <div className="txt-container order">
                      <p className="txt-cont-heading">COMPLETE SECURITY </p>
                      <p>
                        {' '}
                        Our Matrimonial web designs come with a 100% secure
                        admin panel. Also, all the personal informa tion shared
                        by the members stays protected within the website.{' '}
                      </p>
                    </div>
                    <img
                      className="why-us-img"
                      src="https://res.cloudinary.com/jayakrishnavamsi/image/upload/v1667194797/3_btfalp.png"
                      alt="why-us-img"
                    />
                  </div>
                  <div className="why-us-container">
                    <img
                      className="why-us-img"
                      src="https://res.cloudinary.com/jayakrishnavamsi/image/upload/v1667194797/4_ympuqe.png"
                      alt="why-us-img"
                    />
                    <div className="txt-container">
                      <p className="txt-cont-heading">SEO-FRIENDLINESS </p>
                      <p>
                        {' '}
                        Our team of experts develops a matrimonial website
                        enriched with valuable content, SEO friendly URLS, and
                        rightly placed keywords.{' '}
                      </p>
                    </div>
                  </div>
                  <div className="why-us-container">
                    <div className="txt-container order">
                      <p className="txt-cont-heading">SIMPLE NAVIGATION </p>
                      <p>
                        {' '}
                        The intuitive interface and user-friendly navigation
                        help the users to communicate with interested profiles
                        easily.{' '}
                      </p>
                    </div>
                    <img
                      className="why-us-img"
                      src="https://res.cloudinary.com/jayakrishnavamsi/image/upload/v1667194798/5_trteg1.png"
                      alt="why-us-img"
                    />
                  </div>
                </div>
                <div id="subscription-section" className="subscription-section">
                  <h1 className="section-heading subscription-section-title">
                    {' '}
                    Subscriptions{' '}
                  </h1>
                  <div className="subscription-card">
                    <div className="card-s">
                      <h1> $0 </h1>
                      <p> Free </p>
                      <ul>
                        <li> Free Membership </li>
                        <li> Limited Profile Details </li>
                      </ul>
                      <button className="buy-now-btn" type="button">
                        {' '}
                        Buy Now{' '}
                      </button>
                    </div>
                    <div className="card-s">
                      <h1> $15 </h1>
                      <p> Per Month </p>
                      <ul>
                        <li> Profile Detailed View </li>
                        <li> Customer Support </li>
                      </ul>
                      <button className="buy-now-btn" type="button">
                        {' '}
                        Buy Now{' '}
                      </button>
                    </div>
                    <div className="card-s">
                      <h1> $25 </h1>
                      <p> Per Month </p>
                      <ul>
                        <li> Contact Details</li>
                        <li> Profile Detailed View </li>
                      </ul>
                      <button className="buy-now-btn" type="button">
                        {' '}
                        Buy Now{' '}
                      </button>
                    </div>
                  </div>
                </div>
                <div id="map-section" className="map-section">
                  <h1 className="section-heading">Locate Us </h1>
                  <div className="mapouter">
                    <div className="gmap_canvas">
                      <iframe
                        title="google-map"
                        className="gmap_iframe"
                        width="100%"
                        frameBorder="0"
                        scrolling="no"
                        marginHeight="0"
                        marginWidth="0"
                        src="https://maps.google.com/maps?width=642&amp;height=446&amp;hl=en&amp;q=guntur&amp;t=&amp;z=13&amp;ie=UTF8&amp;iwloc=B&amp;output=embed"
                      />
                      <a href="https://piratebay-proxys.com/">Piratebay</a>
                    </div>
                  </div>
                </div>
                <div id="footer-section" className="footer-section">
                  <h1 className="section-heading"> Contact Us</h1>
                  <div className="footer-conts">
                    <div className="contact-us-section">
                      <a className="link" href="#s">
                        ☏ 9908615249
                      </a>
                      <br />
                      <a className="link" href="#s">
                        ✉️ jayakrishnavamsi24@gmail.com
                      </a>
                    </div>
                    <ul className="poilcy-section">
                      <li>
                        {' '}
                        <a className="link" href="#s">
                          {' '}
                          ❧ Privacy Policy{' '}
                        </a>{' '}
                      </li>
                      <li>
                        {' '}
                        <a className="link" href="#s">
                          {' '}
                          ❧ Terms & Conditions{' '}
                        </a>{' '}
                      </li>
                      <li>
                        {' '}
                        <a className="link" href="#s">
                          {' '}
                          ❧ Grievance/ Complaints{' '}
                        </a>{' '}
                      </li>
                    </ul>
                    <div className="subscribe-container">
                      <p className="subscribe-cont-title">
                        {' '}
                        SUBSCRIBE NEWS LETTER{' '}
                      </p>
                      <div className="input-box-cont d-flex">
                        <input
                          type="text"
                          placeholder="Enter your email"
                          className="form-control"
                        />
                        <button className="subscribe-btn"> Subscribe </button>
                      </div>
                      <p className="subscribe-descr">
                        {' '}
                        Get our updates in your mailbox{' '}
                      </p>
                    </div>
                  </div>
                </div>
              </>
            )}
            {!isLandingVisible && (
              <>
                {isSignUpvisible && (
                  <div className="sign-up-form">
                    <h1 className="form-title"> ❥ Create your Account </h1>
                    <form
                      className="sign-up-card"
                      onSubmit={this.onSignupSubmit}
                    >
                      <label htmlFor="firstName"> ☙ First Name </label>
                      <br />
                      <input
                        onChange={this.onfirstNameChange}
                        value={firstName}
                        id="firstName"
                        type="text"
                      />
                      <br />
                      <label htmlFor="middleName"> ☙ Middle Name </label>
                      <br />
                      <input
                        onChange={this.onmiddleNameChange}
                        value={middleName}
                        id="middleName"
                        type="text"
                      />
                      <br />
                      <label htmlFor="lastName"> ☙ Last Name </label>
                      <br />
                      <input
                        onChange={this.onlastNameChange}
                        value={lastName}
                        id="lastName"
                        type="text"
                      />
                      <br />
                      <label htmlFor="email"> ☙ Email </label>
                      <br />
                      <input
                        onChange={this.onemailChange}
                        value={email}
                        id="email"
                        type="text"
                      />
                      <br />
                      <label htmlFor="password"> ☙ Password </label>
                      <br />
                      <input
                        onChange={this.onpasswordChange}
                        value={password}
                        id="password"
                        type="password"
                      />
                      <br />
                      <label htmlFor="gender"> ☙ Gender </label>
                      <br />
                      <select onChange={this.ongenderChange} id="gender">
                        <option value="Male" selected>
                          {' '}
                          Male{' '}
                        </option>
                        <option value="Female"> Female </option>
                        <option value="Other"> Other </option>
                      </select>
                      <br />
                      <label htmlFor="dob"> ☙ Date of Birth </label>
                      <br />
                      <input
                        onChange={this.ondobChange}
                        value={dob}
                        id="dob"
                        type="date"
                      />
                      <br />
                      <label htmlFor="casteorcommunity">
                        {' '}
                        ☙ Cast/Community{' '}
                      </label>
                      <br />
                      <input
                        onChange={this.oncasteChange}
                        value={caste}
                        id="casteorcommunity"
                        type="text"
                      />
                      <br />
                      <label htmlFor="permanentresidence">
                        {' '}
                        ☙ Permanent Residence{' '}
                      </label>
                      <br />
                      <textarea
                        onChange={this.onpermanentaddChange}
                        value={permanentAddress}
                        id="permanentresidence"
                        rows="4"
                        cols="20"
                      />
                      <br />
                      <label htmlFor="currentresidence">
                        {' '}
                        ☙ Current Residence{' '}
                      </label>
                      <br />
                      <textarea
                        onChange={this.oncurrentaddrChange}
                        value={currentAddress}
                        id="currentresidence"
                        rows="4"
                        cols="20"
                      />
                      <br />
                      <label htmlFor="occupation"> ☙ Occupation </label>
                      <br />
                      <input
                        onChange={this.onoccupationChange}
                        value={occupation}
                        id="occupation"
                        type="text"
                      />
                      <br />
                      <label htmlFor="company">
                        {' '}
                        ☙ Working Company/Organisation{' '}
                      </label>
                      <br />
                      <input
                        onChange={this.oncompanyChange}
                        value={company}
                        id="company"
                        type="text"
                      />
                      <br />
                      <label htmlFor="salary"> ☙ Net Salary </label>
                      <br />
                      <input
                        onChange={this.onsalaryChange}
                        value={salary}
                        id="salary"
                        type="number"
                      />
                      <br />
                      <label htmlFor="experience">
                        {' '}
                        ☙ Total Experience(in years){' '}
                      </label>
                      <br />
                      <input
                        onChange={this.onexpereienceChange}
                        value={experience}
                        id="experience"
                        type="number"
                      />
                      <br />
                      <label htmlFor="castepreference">
                        {' '}
                        ☙ Caste Preference{' '}
                      </label>
                      <br />
                      <input
                        onChange={this.oncastePrefChange}
                        value={castePreference}
                        id="castepreference"
                        type="text"
                      />
                      <br />
                      <label htmlFor="agepreference">☙ Age Preference </label>
                      <br />
                      <input
                        onChange={this.onagePrefChange}
                        value={agePreference}
                        id="agepreference"
                        type="number"
                      />
                      <br />
                      <label htmlFor="pspreference">
                        {' '}
                        ☙ Partner Salary Preference{' '}
                      </label>
                      <br />
                      <input
                        onChange={this.onpartnersalarychange}
                        value={partnerSalary}
                        id="pspreference"
                        type="number"
                      />
                      <br />
                      <label htmlFor="phonenumber">☙ Phone Number </label>
                      <br />
                      <input
                        onChange={this.onphonenumberChange}
                        value={phoneNumber}
                        id="phonenumber"
                        type="number"
                      />
                      <br />
                      <div className="btn-cont">
                        <button
                          className="sign-form-button btn-1"
                          type="submit"
                        >
                          {' '}
                          Sign Up{' '}
                        </button>
                      </div>
                    </form>
                  </div>
                )}
                {!isSignUpvisible && (
                  <div className="sign-up-form login-form">
                    <h1 className="form-title"> ❥ Login to your Account </h1>
                    <form
                      className="sign-up-card"
                      onSubmit={this.onLoginSubmit}
                    >
                      <label htmlFor="email"> ☙ Email </label>
                      <br />
                      <input
                        onChange={this.onemailChange}
                        value={email}
                        id="email"
                        type="text"
                      />
                      <br />
                      <label htmlFor="password"> ☙ Password </label>
                      <br />
                      <input
                        onChange={this.onpasswordChange}
                        value={password}
                        id="password"
                        type="password"
                      />
                      <br />
                      <div className="btn-cont">
                        <button
                          className="sign-form-button btn-1"
                          type="submit"
                        >
                          {' '}
                          Login{' '}
                        </button>
                      </div>
                    </form>
                  </div>
                )}
              </>
            )}
          </>
        )}
      </div>
    )
  }
}

export default App
