import './index.css'

const ProfileItem = props => {
  const {userDetails, cardClick} = props
  const {
    id,
    firstName,
    middleName,
    lastName,
    imgUrl,
    profileId,
    email,
    password,
    gender,
    dob,
    caste,
    permanentAddress,
    currentAddress,
    occupation,
    company,
    salary,
    experience,
    castePreference,
    agePreference,
    partnerSalary,
    phoneNumber,
  } = userDetails

  let {age} = userDetails

  function getAge(dateString) {
    const today = new Date()
    const dobArray = dateString.split('-')
    const birthYear = dobArray[0]
    const birthMonth = dobArray[1]
    const birthDay = dobArray[2]
    const birthDate = new Date(birthYear, birthMonth, birthDay)
    age = today.getFullYear() - birthDate.getFullYear()
    const m = today.getMonth() - birthDate.getMonth()
    if (m < 0 || (m === 0 && today.getDate() < birthDate.getDate())) {
      age = age - 1
    }
    return age
  }

  age = getAge(dob)

  const onCardClick = () => {
    cardClick(id)
  }

  return (
    <button type="button" onClick={onCardClick} className="profiles-container">
      <div className="person-profile">
        <div className="img-container">
          <img className="person-img" src={imgUrl} alt="person-profile" />
        </div>

        <div className="profile-card-txt-cont">
          <p className="profiletxt"> Profile-Id: {profileId} </p>
          <p className="profiletxt">
            {' '}
            Name:{' '}
            <span className="masked-name">
              {' '}
              {`${firstName} ${middleName} ${lastName}`}{' '}
            </span>{' '}
          </p>
          <p className="profiletxt">
            {' '}
            Age: <span className="age-number"> {age} </span>{' '}
          </p>
        </div>
      </div>
    </button>
  )
}

export default ProfileItem
